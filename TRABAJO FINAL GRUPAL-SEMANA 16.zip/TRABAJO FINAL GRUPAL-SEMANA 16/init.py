import json
import os
from datetime import datetime

def listar_partidas():
    partidas = []
    if os.path.exists('partidas'):
        archivos = os.listdir('partidas')
        for archivo in archivos:
            if archivo.endswith('.json'):
                partidas.append(archivo)
    return partidas

def seleccionar_partida():
    partidas = listar_partidas()
    
    if not partidas:
        print("No hay partidas guardadas")
        return crear_nueva_partida()
    
    print("\n=== PARTIDAS GUARDADAS ===")
    for i, partida in enumerate(partidas, 1):
        nombre_partida = partida.replace('.json', '')
        print(f"{i}. {nombre_partida}")
    print(f"{len(partidas) + 1}. Nueva partida")
    
    try:
        opcion = int(input("\nSelecciona una opcion: "))
        if opcion == len(partidas) + 1:
            return crear_nueva_partida()
        elif 1 <= opcion <= len(partidas):
            archivo = partidas[opcion - 1]
            return cargar_partida_archivo(archivo)
        else:
            print("Opcion invalida")
            return seleccionar_partida()
    except:
        print("Opcion invalida")
        return seleccionar_partida()

def cargar_partida_archivo(archivo):
    try:
        ruta = os.path.join('partidas', archivo)
        with open(ruta, 'r', encoding='utf-8') as f:
            datos = json.load(f)
        print(f"Partida '{archivo.replace('.json', '')}' cargada")
        datos['nombre_archivo'] = archivo
        return datos
    except:
        print("Error al cargar partida")
        return crear_nueva_partida()

def crear_nueva_partida():
    print("\n=== CREAR PERSONAJE ===")
    nombre = input("Nombre del heroe: ").strip()
    if not nombre:
        nombre = "Heroe"
    
    nombre_limpio = nombre.replace(' ', '_')
    
    datos = {
        "nombre_archivo": f"{nombre_limpio}.json",
        "personaje": {
            "nombre": nombre,
            "nivel": 1,
            "vida_max": 100,
            "vida": 100,
            "ataque": 10,
            "defensa": 5,
            "oro": 100,
            "exp": 0,
            "exp_necesaria": 100
        },
        "inventario": [
            {"id": 1, "nombre": "Pocion pequeña", "tipo": "pocion", "cura": 25, "cantidad": 5},
            {"id": 2, "nombre": "Espada basica", "tipo": "arma", "ataque": 5, "equipado": True}
        ],
        "estadisticas": {
            "enemigos_muertos": 0,
            "batallas_ganadas": 0,
            "batallas_perdidas": 0,
            "pociones_usadas": 0,
            "oro_ganado": 0,
            "fecha_inicio": datetime.now().strftime("%Y-%m-%d %H:%M")
        }
    }
    
    print(f"\nBienvenido {nombre}!")
    return datos

def guardar_partida(datos):
    try:
        if not os.path.exists('partidas'):
            os.makedirs('partidas')
        
        archivo = datos.get('nombre_archivo', 'partida.json')
        ruta = os.path.join('partidas', archivo)
        
        with open(ruta, 'w', encoding='utf-8') as f:
            json.dump(datos, f, indent=2, ensure_ascii=False)
        return True
    except:
        return False

def eliminar_partida(datos):
    try:
        archivo = datos.get('nombre_archivo', 'partida.json')
        ruta = os.path.join('partidas', archivo)
        
        if os.path.exists(ruta):
            os.remove(ruta)
            print("Partida eliminada")
            return True
        else:
            print("No se encontro el archivo")
            return False
    except:
        print("Error al eliminar")
        return False

def lista_enemigos():
    return {
        1: [
            {"nombre": "Slime", "vida": 30, "ataque": 5, "defensa": 2, "oro": 15, "exp": 25},
            {"nombre": "Rata gigante", "vida": 35, "ataque": 6, "defensa": 2, "oro": 18, "exp": 28},
            {"nombre": "Murcielago", "vida": 25, "ataque": 7, "defensa": 1, "oro": 20, "exp": 30}
        ],
        2: [
            {"nombre": "Goblin", "vida": 50, "ataque": 10, "defensa": 4, "oro": 30, "exp": 45},
            {"nombre": "Lobo", "vida": 55, "ataque": 12, "defensa": 3, "oro": 35, "exp": 50},
            {"nombre": "Esqueleto", "vida": 60, "ataque": 11, "defensa": 5, "oro": 40, "exp": 55}
        ],
        3: [
            {"nombre": "Orco", "vida": 85, "ataque": 18, "defensa": 8, "oro": 60, "exp": 85},
            {"nombre": "Troll", "vida": 95, "ataque": 20, "defensa": 10, "oro": 70, "exp": 95},
            {"nombre": "Dragon joven", "vida": 120, "ataque": 25, "defensa": 12, "oro": 100, "exp": 120}
        ]
    }

def items_tienda():
    return [
        {"id": 101, "nombre": "Pocion pequeña", "tipo": "pocion", "cura": 25, "precio": 20},
        {"id": 102, "nombre": "Pocion mediana", "tipo": "pocion", "cura": 50, "precio": 40},
        {"id": 103, "nombre": "Pocion grande", "tipo": "pocion", "cura": 80, "precio": 65},
        {"id": 104, "nombre": "Pocion completa", "tipo": "pocion", "cura": 150, "precio": 100},
        
        {"id": 201, "nombre": "Espada de hierro", "tipo": "arma", "ataque": 8, "precio": 60},
        {"id": 202, "nombre": "Espada de acero", "tipo": "arma", "ataque": 12, "precio": 100},
        {"id": 203, "nombre": "Espada de plata", "tipo": "arma", "ataque": 18, "precio": 180},
        {"id": 204, "nombre": "Espada legendaria", "tipo": "arma", "ataque": 25, "precio": 300},
        
        {"id": 301, "nombre": "Armadura de cuero", "tipo": "armadura", "defensa": 5, "precio": 55},
        {"id": 302, "nombre": "Armadura de hierro", "tipo": "armadura", "defensa": 8, "precio": 90},
        {"id": 303, "nombre": "Armadura de acero", "tipo": "armadura", "defensa": 12, "precio": 150},
        {"id": 304, "nombre": "Armadura de mithril", "tipo": "armadura", "defensa": 18, "precio": 250},
        
        {"id": 401, "nombre": "Escudo pequeño", "tipo": "escudo", "defensa": 4, "precio": 45},
        {"id": 402, "nombre": "Escudo mediano", "tipo": "escudo", "defensa": 7, "precio": 80},
        {"id": 403, "nombre": "Escudo grande", "tipo": "escudo", "defensa": 11, "precio": 140},
        {"id": 404, "nombre": "Escudo de dragon", "tipo": "escudo", "defensa": 16, "precio": 230}
    ]