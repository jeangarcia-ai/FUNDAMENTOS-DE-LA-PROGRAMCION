from init import seleccionar_partida, guardar_partida, eliminar_partida
from funciones import ver_personaje, ver_inventario, usar_pocion, comprar, equipar, ver_stats, explorar, descansar, eliminar_item, mejorar_item, cambiar_nombre

def menu():
    print("\n==================================")
    print("      AVENTURA DEL HEROE")
    print("==================================")
    print("1. Explorar")
    print("2. Ver personaje")
    print("3. Ver inventario")
    print("4. Usar pocion")
    print("5. Equipar item")
    print("6. Tienda")
    print("7. Descansar")
    print("8. Eliminar item")
    print("9. Mejorar item")
    print("10. Estadisticas")
    print("11. Cambiar nombre")
    print("12. Eliminar partida")
    print("13. Guardar y salir")
    print("==================================")

def main():
    print("Iniciando juego...")
    
    datos = seleccionar_partida()
    
    personaje = datos['personaje']
    inventario = datos['inventario']
    stats = datos['estadisticas']
    
    print(f"\nBienvenido {personaje['nombre']}")
    
    while True:
        menu()
        
        opcion = input("\nElige opcion: ").strip()
        
        if opcion == "1":
            personaje, inventario, stats = explorar(personaje, inventario, stats)
        
        elif opcion == "2":
            ver_personaje(personaje)
        
        elif opcion == "3":
            ver_inventario(inventario)
        
        elif opcion == "4":
            personaje, inventario = usar_pocion(personaje, inventario)
        
        elif opcion == "5":
            personaje, inventario = equipar(personaje, inventario)
        
        elif opcion == "6":
            personaje, inventario = comprar(personaje, inventario)
        
        elif opcion == "7":
            personaje = descansar(personaje)
        
        elif opcion == "8":
            inventario = eliminar_item(inventario)
        
        elif opcion == "9":
            personaje, inventario = mejorar_item(personaje, inventario)
        
        elif opcion == "10":
            ver_stats(stats, personaje)
        
        elif opcion == "11":
            personaje, datos = cambiar_nombre(personaje, datos)
        
        elif opcion == "12":
            confirmacion = input("Seguro que quieres eliminar esta partida? (si/no): ")
            if confirmacion.lower() == "si":
                if eliminar_partida(datos):
                    print("Partida eliminada. Volviendo al inicio...")
                    main()
                    return
        
        elif opcion == "13":
            print("\nGuardando...")
            
            datos['personaje'] = personaje
            datos['inventario'] = inventario
            datos['estadisticas'] = stats
            
            if guardar_partida(datos):
                print("Partida guardada")
            else:
                print("Error al guardar")
            
            print("Hasta luego")
            break
        
        else:
            print("Opcion invalida")
        
        input("\nPresiona Enter para continuar...")

if __name__ == "__main__":
    main()