import random
from init import lista_enemigos, items_tienda

def ver_personaje(personaje):
    print("\n==================================")
    print(f"Nombre: {personaje['nombre']}")
    print(f"Nivel: {personaje['nivel']}")
    print(f"Vida: {personaje['vida']}/{personaje['vida_max']}")
    print(f"Ataque: {personaje['ataque']}")
    print(f"Defensa: {personaje['defensa']}")
    print(f"Oro: {personaje['oro']}")
    print(f"Experiencia: {personaje['exp']}/{personaje['exp_necesaria']}")
    print("==================================")

def ver_inventario(inventario):
    print("\n=== INVENTARIO ===")
    if not inventario:
        print("Inventario vacio")
        return
    
    for item in inventario:
        texto = f"[{item['id']}] {item['nombre']}"
        
        if item['tipo'] == 'pocion':
            texto += f" - Cura {item['cura']} HP (x{item.get('cantidad', 1)})"
        elif item['tipo'] == 'arma':
            texto += f" - Ataque +{item['ataque']}"
            if item.get('equipado'):
                texto += " [EQUIPADO]"
        elif item['tipo'] in ['armadura', 'escudo']:
            texto += f" - Defensa +{item['defensa']}"
            if item.get('equipado'):
                texto += " [EQUIPADO]"
        
        print(texto)

def usar_pocion(personaje, inventario):
    print("\n=== USAR POCION ===")
    
    pociones = [item for item in inventario if item['tipo'] == 'pocion']
    
    if not pociones:
        print("No tienes pociones")
        return personaje, inventario
    
    print("Pociones disponibles:")
    for pocion in pociones:
        print(f"[{pocion['id']}] {pocion['nombre']} - Cura {pocion['cura']} HP (x{pocion['cantidad']})")
    
    try:
        id_elegido = int(input("\nID de la pocion (0 para cancelar): "))
        if id_elegido == 0:
            return personaje, inventario
    except:
        print("ID invalido")
        return personaje, inventario
    
    for item in inventario:
        if item['id'] == id_elegido and item['tipo'] == 'pocion':
            vida_curada = min(item['cura'], personaje['vida_max'] - personaje['vida'])
            personaje['vida'] += vida_curada
            
            print(f"\nUsaste {item['nombre']}")
            print(f"Recuperaste {vida_curada} puntos de vida")
            print(f"Vida actual: {personaje['vida']}/{personaje['vida_max']}")
            
            item['cantidad'] -= 1
            if item['cantidad'] <= 0:
                inventario.remove(item)
            
            return personaje, inventario
    
    print("Pocion no encontrada")
    return personaje, inventario

def pelear(personaje, inventario, stats, nivel):
    enemigos_disponibles = lista_enemigos().get(nivel, lista_enemigos()[1])
    enemigo = random.choice(enemigos_disponibles).copy()
    
    print("\n==================================")
    print(f"Aparecio un {enemigo['nombre']}!")
    print(f"Vida: {enemigo['vida']}")
    print(f"Ataque: {enemigo['ataque']}")
    print(f"Defensa: {enemigo['defensa']}")
    print("==================================")
    
    turno = 1
    
    while personaje['vida'] > 0 and enemigo['vida'] > 0:
        print(f"\n--- Turno {turno} ---")
        print(f"Tu vida: {personaje['vida']}/{personaje['vida_max']} | Enemigo: {enemigo['vida']}")
        
        print("\n1. Atacar")
        print("2. Usar pocion")
        print("3. Huir")
        
        opcion = input("Que haces? ")
        
        if opcion == "1":
            daño = max(1, personaje['ataque'] - enemigo['defensa'])
            enemigo['vida'] -= daño
            
            print(f"\nAtacaste al {enemigo['nombre']}")
            print(f"Daño causado: {daño}")
            
            if enemigo['vida'] <= 0:
                print(f"\nDerrotaste al {enemigo['nombre']}!")
                
                personaje['oro'] += enemigo['oro']
                personaje['exp'] += enemigo['exp']
                stats['enemigos_muertos'] += 1
                stats['batallas_ganadas'] += 1
                stats['oro_ganado'] += enemigo['oro']
                
                print(f"Ganaste {enemigo['oro']} oro")
                print(f"Ganaste {enemigo['exp']} EXP")
                
                personaje, stats = subir_nivel(personaje, stats)
                return personaje, inventario, stats, True
        
        elif opcion == "2":
            personaje, inventario = usar_pocion(personaje, inventario)
            stats['pociones_usadas'] += 1
        
        elif opcion == "3":
            if random.random() < 0.5:
                print("Escapaste!")
                return personaje, inventario, stats, False
            else:
                print("No pudiste escapar!")
        
        else:
            print("Opcion invalida")
        
        if enemigo['vida'] > 0:
            daño_enemigo = max(1, enemigo['ataque'] - personaje['defensa'])
            personaje['vida'] -= daño_enemigo
            
            print(f"\nEl {enemigo['nombre']} te ataca")
            print(f"Daño recibido: {daño_enemigo}")
            print(f"Tu vida: {personaje['vida']}/{personaje['vida_max']}")
            
            if personaje['vida'] <= 0:
                print("\nFuiste derrotado")
                stats['batallas_perdidas'] += 1
                personaje['oro'] = max(0, personaje['oro'] - 30)
                personaje['vida'] = personaje['vida_max'] // 2
                print("Perdiste 30 oro")
                print("Volviste a la aldea con la mitad de tu vida")
                return personaje, inventario, stats, False
        
        turno += 1
    
    return personaje, inventario, stats, False

def subir_nivel(personaje, stats):
    while personaje['exp'] >= personaje['exp_necesaria']:
        personaje['nivel'] += 1
        personaje['exp'] -= personaje['exp_necesaria']
        personaje['exp_necesaria'] = int(personaje['exp_necesaria'] * 1.5)
        
        personaje['vida_max'] += 20
        personaje['vida'] = personaje['vida_max']
        personaje['ataque'] += 3
        personaje['defensa'] += 2
        
        print("\n==================================")
        print(f"SUBISTE AL NIVEL {personaje['nivel']}!")
        print(f"Vida maxima: {personaje['vida_max']}")
        print(f"Ataque: {personaje['ataque']}")
        print(f"Defensa: {personaje['defensa']}")
        print("Vida restaurada completamente")
        print("==================================")
    
    return personaje, stats

def comprar(personaje, inventario):
    print("\n==================================")
    print("TIENDA")
    print(f"Tu oro: {personaje['oro']}")
    print("==================================")
    
    items = items_tienda()
    
    while True:
        print("\nItems disponibles:")
        for item in items:
            texto = f"[{item['id']}] {item['nombre']} - {item['precio']} oro"
            if item['tipo'] == 'pocion':
                texto += f" (Cura {item['cura']} HP)"
            elif item['tipo'] == 'arma':
                texto += f" (Ataque +{item['ataque']})"
            elif item['tipo'] in ['armadura', 'escudo']:
                texto += f" (Defensa +{item['defensa']})"
            print(texto)
        
        print("\n[0] Salir")
        
        try:
            opcion = int(input("\nID del item: "))
            if opcion == 0:
                break
        except:
            print("Opcion invalida")
            continue
        
        item_comprar = None
        for item in items:
            if item['id'] == opcion:
                item_comprar = item.copy()
                break
        
        if not item_comprar:
            print("Item no encontrado")
            continue
        
        if personaje['oro'] < item_comprar['precio']:
            print(f"No tienes suficiente oro. Necesitas {item_comprar['precio']} oro")
            continue
        
        personaje['oro'] -= item_comprar['precio']
        
        if item_comprar['tipo'] == 'pocion':
            encontrado = False
            for inv_item in inventario:
                if inv_item['nombre'] == item_comprar['nombre']:
                    inv_item['cantidad'] = inv_item.get('cantidad', 1) + 1
                    encontrado = True
                    break
            if not encontrado:
                item_comprar['cantidad'] = 1
                inventario.append(item_comprar)
        else:
            item_comprar['equipado'] = False
            inventario.append(item_comprar)
        
        print(f"Compraste {item_comprar['nombre']}")
        print(f"Oro restante: {personaje['oro']}")
    
    return personaje, inventario

def equipar(personaje, inventario):
    print("\n=== EQUIPAR ===")
    
    equipables = [item for item in inventario if item['tipo'] in ['arma', 'armadura', 'escudo']]
    
    if not equipables:
        print("No tienes items equipables")
        return personaje, inventario
    
    print("Items equipables:")
    for item in equipables:
        estado = "[EQUIPADO]" if item.get('equipado') else ""
        print(f"[{item['id']}] {item['nombre']} {estado}")
    
    try:
        id_item = int(input("\nID del item (0 para cancelar): "))
        if id_item == 0:
            return personaje, inventario
    except:
        print("ID invalido")
        return personaje, inventario
    
    for item in inventario:
        if item['id'] == id_item and item['tipo'] in ['arma', 'armadura', 'escudo']:
            for otro in inventario:
                if otro['tipo'] == item['tipo'] and otro.get('equipado'):
                    otro['equipado'] = False
                    if item['tipo'] == 'arma':
                        personaje['ataque'] -= otro.get('ataque', 0)
                    else:
                        personaje['defensa'] -= otro.get('defensa', 0)
            
            item['equipado'] = True
            if item['tipo'] == 'arma':
                personaje['ataque'] += item.get('ataque', 0)
                print(f"Equipaste {item['nombre']}")
            else:
                personaje['defensa'] += item.get('defensa', 0)
                print(f"Equipaste {item['nombre']}")
            
            return personaje, inventario
    
    print("Item no encontrado")
    return personaje, inventario

def ver_stats(stats, personaje):
    print("\n==================================")
    print("ESTADISTICAS")
    print(f"Enemigos derrotados: {stats['enemigos_muertos']}")
    print(f"Batallas ganadas: {stats['batallas_ganadas']}")
    print(f"Batallas perdidas: {stats['batallas_perdidas']}")
    print(f"Pociones usadas: {stats['pociones_usadas']}")
    print(f"Oro ganado: {stats['oro_ganado']}")
    print(f"Nivel actual: {personaje['nivel']}")
    print(f"Fecha inicio: {stats['fecha_inicio']}")
    print("==================================")

def explorar(personaje, inventario, stats):
    print("\n=== EXPLORANDO ===")
    
    evento = random.choice(['pelea', 'pelea', 'oro', 'nada'])
    
    if evento == 'pelea':
        print("Encontraste un enemigo")
        nivel_mazmorra = min(3, (personaje['nivel'] + 1) // 2)
        personaje, inventario, stats, victoria = pelear(personaje, inventario, stats, nivel_mazmorra)
    elif evento == 'oro':
        oro_encontrado = random.randint(20, 50)
        personaje['oro'] += oro_encontrado
        print(f"Encontraste {oro_encontrado} oro")
        stats['oro_ganado'] += oro_encontrado
    else:
        print("No encontraste nada")
    
    return personaje, inventario, stats

def descansar(personaje):
    print("\nDescansando...")
    recuperado = personaje['vida_max'] // 2
    personaje['vida'] = min(personaje['vida_max'], personaje['vida'] + recuperado)
    print(f"Recuperaste {recuperado} puntos de vida")
    print(f"Vida actual: {personaje['vida']}/{personaje['vida_max']}")
    return personaje

def eliminar_item(inventario):
    print("\n=== ELIMINAR ITEM ===")
    
    if not inventario:
        print("Inventario vacio")
        return inventario
    
    print("Items en inventario:")
    for item in inventario:
        texto = f"[{item['id']}] {item['nombre']}"
        if item['tipo'] == 'pocion':
            texto += f" (x{item.get('cantidad', 1)})"
        print(texto)
    
    try:
        id_item = int(input("\nID del item a eliminar (0 para cancelar): "))
        if id_item == 0:
            return inventario
    except:
        print("ID invalido")
        return inventario
    
    for item in inventario:
        if item['id'] == id_item:
            if item['tipo'] == 'pocion' and item.get('cantidad', 1) > 1:
                item['cantidad'] -= 1
                print(f"Eliminaste 1 {item['nombre']}")
                print(f"Quedan {item['cantidad']}")
            else:
                inventario.remove(item)
                print(f"Eliminaste {item['nombre']}")
            return inventario
    
    print("Item no encontrado")
    return inventario

def mejorar_item(personaje, inventario):
    print("\n=== MEJORAR ITEM ===")
    
    mejorables = [item for item in inventario if item['tipo'] in ['arma', 'armadura', 'escudo']]
    
    if not mejorables:
        print("No tienes items para mejorar")
        return personaje, inventario
    
    print("Items mejorables:")
    for item in mejorables:
        if item['tipo'] == 'arma':
            costo = item.get('ataque', 0) * 15
            print(f"[{item['id']}] {item['nombre']} - Costo: {costo} oro (+2 ataque)")
        else:
            costo = item.get('defensa', 0) * 15
            print(f"[{item['id']}] {item['nombre']} - Costo: {costo} oro (+2 defensa)")
    
    try:
        id_item = int(input("\nID del item a mejorar (0 para cancelar): "))
        if id_item == 0:
            return personaje, inventario
    except:
        print("ID invalido")
        return personaje, inventario
    
    for item in inventario:
        if item['id'] == id_item and item['tipo'] in ['arma', 'armadura', 'escudo']:
            if item['tipo'] == 'arma':
                costo = item.get('ataque', 0) * 15
            else:
                costo = item.get('defensa', 0) * 15
            
            if personaje['oro'] < costo:
                print(f"No tienes suficiente oro. Necesitas {costo} oro")
                return personaje, inventario
            
            personaje['oro'] -= costo
            
            if item['tipo'] == 'arma':
                item['ataque'] += 2
                if item.get('equipado'):
                    personaje['ataque'] += 2
                print(f"Mejoraste {item['nombre']} a +{item['ataque']} ataque")
            else:
                item['defensa'] += 2
                if item.get('equipado'):
                    personaje['defensa'] += 2
                print(f"Mejoraste {item['nombre']} a +{item['defensa']} defensa")
            
            print(f"Oro restante: {personaje['oro']}")
            return personaje, inventario
    
    print("Item no encontrado")
    return personaje, inventario

def cambiar_nombre(personaje, datos):
    print("\n=== CAMBIAR NOMBRE ===")
    print(f"Nombre actual: {personaje['nombre']}")
    
    nuevo_nombre = input("Nuevo nombre (0 para cancelar): ").strip()
    
    if nuevo_nombre == "0" or not nuevo_nombre:
        print("Cancelado")
        return personaje, datos
    
    nombre_anterior = personaje['nombre']
    personaje['nombre'] = nuevo_nombre
    
    nombre_limpio = nuevo_nombre.replace(' ', '_')
    datos['nombre_archivo'] = f"{nombre_limpio}.json"
    
    print(f"Nombre cambiado de '{nombre_anterior}' a '{nuevo_nombre}'")
    return personaje, datos